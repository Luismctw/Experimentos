/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package com.mycompany.menu_proyect;


import java.util.Scanner;

/**
 *
 * @author GOITMX HP
 */
public class Menu_proyect {

    public static void main(String[] args) {
        System.out.println(" MENU ");
        System.out.println(" 1-ELEGIR ASIENTO ");
        System.out.println(" 2-CAMBIO DE ASIENTO ");
        System.out.println(" 3-CANCELAR ASIENTO ");
        System.out.println(" 4-MOSTRAR TU ASIENTO");
        System.out.println(" 5-SALIR DEL PROGRAMA ");
        
        int o= 10;
        int p= 4;
        
        int arreglo[][]=new int[o][p];
        
        int a=4;
        int z=1;
        
        do {
        System.out.println(" DIME QUE QUIERES HACER ");
        Scanner intro=new Scanner(System.in);
        
        int op=intro.nextInt();
        
        
              
            switch (op) {
            case 1: 
                
                System.out.println(" ELEGIR ASIENTO ");
            
                for (int i = 0; i < arreglo.length; i++) {            
                     for (int j = 0; j < a; j++) {
                            System.out.print(arreglo[i][j]=z++);
                        }
                     
                            System.out.println(" ");
                    }
                                
                 System.out.println("que lugar quieres");
            
                 int w=intro.nextInt();  
            
                 for (int i = 0; i < arreglo.length; i++) {
                      for (int j = 0; j < a; j++) {
                          if (arreglo[i][j]==w) {
                              arreglo[i][j]=0;
                            }
                        }
                    }
            
            for (int i = 0; i < arreglo.length; i++) {                
                for (int j = 0; j <a; j++) {
                    System.out.print(arreglo[i][j]);                   
                }      
                System.out.println(" ");
            }  
            
            break;                       
            
            case 2: 
                System.out.println(" CAMBIO DE ASIENTO ");
                             
            break;
            
            case 3: 
                System.out.println(" ELIMINAR ASIENTO");
            break;

            
            case 4: 
                System.out.println(" ESTE ES TU ASIENTO ");
                           
            
                 for (int i = 0; i < arreglo.length; i++) {
                      for (int j = 0; j < a; j++) {
                          if (arreglo[i][j]==0) {
                              arreglo[i][j]=0;
                            }
                        }
                    }
            
            for (int i = 0; i < arreglo.length; i++) {                
                for (int j = 0; j < a; j++) {
                    System.out.print(arreglo[i][j]);
                }      
                System.out.println(" ");
            }  
            break;
            
            case 5: 
                System.out.println(" VULVA PRONTO O MEJOR NO ");
            break;
            
            
            default: System.out.println(" RSTA OPCION NO EXISTE ");
                   
            }
        }while (true);
    }
}
