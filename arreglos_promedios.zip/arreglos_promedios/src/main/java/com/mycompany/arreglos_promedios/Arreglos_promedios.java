/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package com.mycompany.arreglos_promedios;

import java.util.Scanner;

/**
 *
 * @author GOITMX HP
 */
public class Arreglos_promedios {

    public static void main(String[] args) {//LUIS ALBERTO MARTINEZ CHAIRES GRUPO 519 
       Scanner intro=new Scanner (System.in);
        
        System.out.println("De que semestre eres?");
         
        String materias[]=new String[9];//esta es la cantidad de materias que hay en cada semestre
        
        int num=intro.nextInt();
        
        int cali[]=new int[9];//esta es la cantidad de calificaciones por cada semestre
        
        double sum=0;
        
        double lol=9;//lol es la variable que sirve para dividir el resultado entre las materias
        
        double resu=0;
        
        switch (num){
            
            case 1:
                System.out.println("semestre 1");
                for (int i = 0; i < 9; i++) {
                    System.out.println("dame el nombre de tu materia "+(i+1));
                    materias[i]=intro.next();
                    System.out.println("cual es la calificacion");
                    cali[i]=intro.nextInt();
                    sum= sum + cali[i];//esto es lo que suma todas las calificaciones del semestre
                }
                
                resu=sum/lol;//esto es lo que permite dividir las calificaciones entre las materias para el promedio general
                
                for (int i = 0; i < 9; i++) {
                System.out.println("la materia "+materias[i]+" tiene como calificacion "+cali[i]);
                }
                
                System.out.println("tu promedio general de este semestre es "+resu);
                
                break; 
                
                case 2:
                System.out.println("semestre 2");
                for (int i = 0; i < 9; i++) {
                    System.out.println("dame el nombre de tu materia "+(i+1));
                    materias[i]=intro.next();
                    System.out.println("cual es la calificacion");
                    cali[i]=intro.nextInt();
                    sum= sum + cali[i];
                }
                
                resu=sum/lol;
                
                for (int i = 0; i < 9; i++) {
                System.out.println("la materia "+materias[i]+" tiene como calificacion "+cali[i]);
                }
                
                System.out.println("tu promedio general de este semestre es "+resu);
                
                break; 
                case 3:
                System.out.println("semestre 3");
                for (int i = 0; i < 9; i++) {
                    System.out.println("dame el nombre de tu materia "+(i+1));
                    materias[i]=intro.next();
                    System.out.println("cual es la calificacion");
                    cali[i]=intro.nextInt();
                    sum= sum + cali[i];
                }
                
                resu=sum/lol;
                
                for (int i = 0; i < 9; i++) {
                System.out.println("la materia "+materias[i]+" tiene como calificacion "+cali[i]);
                }
                
                System.out.println("tu promedio general de este semestre es "+resu);
                
                break; 
                case 4:
                System.out.println("semestre 4");
                for (int i = 0; i < 9; i++) {
                    System.out.println("dame el nombre de tu materia "+(i+1));
                    materias[i]=intro.next();
                    System.out.println("cual es la calificacion");
                    cali[i]=intro.nextInt();
                    sum= sum + cali[i];
                }
                
                resu=sum/lol;
                
                for (int i = 0; i < 9; i++) {
                System.out.println("la materia "+materias[i]+" tiene como calificacion "+cali[i]);
                }
                
                System.out.println("tu promedio general de este semestre es "+resu);
                
                break; 
                case 5:
                System.out.println("semestre 5");
                for (int i = 0; i < 9; i++) {
                    System.out.println("dame el nombre de tu materia "+(i+1));
                    materias[i]=intro.next();
                    System.out.println("cual es la calificacion");
                    cali[i]=intro.nextInt();
                    sum= sum + cali[i];
                }
                
                resu=sum/lol;
                
                for (int i = 0; i < 9; i++) {
                System.out.println("la materia "+materias[i]+" tiene como calificacion "+cali[i]);
                }
                
                System.out.println("tu promedio general de este semestre es "+resu);
                
                break; 
                case 6:
                System.out.println("semestre 6");
                for (int i = 0; i < 9; i++) {
                    System.out.println("dame el nombre de tu materia "+(i+1));
                    materias[i]=intro.next();
                    System.out.println("cual es la calificacion");
                    cali[i]=intro.nextInt();
                    sum= sum + cali[i];
                }
                
                resu=sum/lol;
                
                for (int i = 0; i < 9; i++) {
                System.out.println("la materia "+materias[i]+" tiene como calificacion "+cali[i]);
                }
                
                System.out.println("tu promedio general de este semestre es "+resu);
                
                break; 
                
            default: 
                System.out.println("este semestre no existe baboso");
        }
    }
        
}



       

